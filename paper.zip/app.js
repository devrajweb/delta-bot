import dotenv from "dotenv";
dotenv.config();

import sequelize from "./config/database.js";
import TradeModel from "./models/Trade.js";
import DailyPnlModel from "./models/DailyPnl.js";
import { DataTypes } from "sequelize";

import { startDeltaWS } from "./services/deltaWs.js";
import { tryEntry } from "./services/tradeExecutor.js";
import { checkExit } from "./services/exitManager.js";

const Trade = TradeModel(sequelize, DataTypes);
DailyPnlModel(sequelize, DataTypes);

(async () => {
  await sequelize.sync();
  console.log("✅ Database Ready");

  startDeltaWS(async (symbol, price) => {
    await tryEntry(symbol, price, Trade);
    await checkExit(symbol, price, Trade);
  });
})();
