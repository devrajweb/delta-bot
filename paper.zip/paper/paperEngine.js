export function paperBuy(symbol, qty, price) {
  return {
    symbol,
    qty,
    entry_price: price,
    order_id: "PAPER_BUY_" + Date.now(),
    timestamp: new Date().toISOString(),
  };
}

export function paperSell(symbol, qty, price) {
  return {
    symbol,
    qty,
    exit_price: price,
    order_id: "PAPER_SELL_" + Date.now(),
    timestamp: new Date().toISOString(),
  };
}
