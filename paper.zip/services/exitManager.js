import { closeTrade } from "./tradeExecutor.js";
import { paperBuy, paperSell } from "../paper/paperEngine.js";

export async function checkExit(symbol, price, Trade) {
  const trade = await Trade.findOne({ where: { symbol, status: "OPEN" } });
  if (!trade) return;

  let exitReason = "";
  let isProfit = false;
  let pnl = 0;

  const isLong = trade.side === "BUY";

  if (isLong) {
    // LONG position: profit if price goes up
    if (price >= trade.target_price) {
      exitReason = `TARGET HIT 🎯`;
      isProfit = true;
    } else if (price <= trade.stop_loss) {
      exitReason = `STOP LOSS 🛑`;
      isProfit = false;
    } else {
      return;
    }
    pnl = price - trade.entry_price;
    paperSell(symbol, trade.qty, price); // Close LONG with SELL
  } else {
    // SHORT position: profit if price goes down
    if (price <= trade.target_price) {
      exitReason = `TARGET HIT 🎯`;
      isProfit = true;
    } else if (price >= trade.stop_loss) {
      exitReason = `STOP LOSS 🛑`;
      isProfit = false;
    } else {
      return;
    }
    pnl = trade.entry_price - price; // For SHORT: entry - exit
    paperBuy(symbol, trade.qty, price); // Close SHORT with BUY
  }

  const pnlPercent = ((pnl / trade.entry_price) * 100).toFixed(2);
  const emoji = isProfit ? "📈" : "📉";
  const action = isLong ? "SELL" : "BUY";

  // Update trade record
  trade.exit_price = price;
  trade.status = "CLOSED";
  trade.pnl = pnl;
  await trade.save();

  closeTrade(symbol);
  console.log(
    `${emoji} ${action} (Close) ${symbol} | Qty: ${trade.qty} @ $${price.toFixed(2)} | PnL: $${pnl.toFixed(
      2
    )} (${pnlPercent}%) | ${exitReason}`
  );
}
