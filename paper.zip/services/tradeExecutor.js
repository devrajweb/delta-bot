import strategy from "../config/strategy.config.js";
import coins from "../config/coins.js";
import { paperBuy, paperSell } from "../paper/paperEngine.js";

let openTrades = {};
let tradeCount = {}; // Track trades per symbol

// Get qty from coins config
function getQtyForSymbol(symbol) {
  const coin = coins.find((c) => c.symbol === symbol);
  return coin ? coin.qty : 1;
}

export async function tryEntry(symbol, price, Trade) {
  // Check if already in trade
  if (openTrades[symbol]) return;

  // Random entry (50% chance for testing - change to 0.03 for production)
  if (Math.random() > 0.5) return;

  const qty = getQtyForSymbol(symbol);

  // 50/50 chance of LONG or SHORT
  const isLong = Math.random() > 0.5;

  if (isLong) {
    // LONG: BUY to open
    const target = price * (1 + strategy.targetPercent / 100);
    const stop = price * (1 - strategy.stopLossPercent / 100);

    paperBuy(symbol, qty, price);

    await Trade.create({
      symbol,
      side: "BUY",
      qty: qty,
      entry_price: price,
      target_price: target,
      stop_loss: stop,
      mode: process.env.TRADING_MODE,
    });

    openTrades[symbol] = true;
    const count = tradeCount[symbol] || 0;
    tradeCount[symbol] = count + 1;
    console.log(
      `🟢 LONG ${symbol} | Qty: ${qty} @ $${price.toFixed(2)} | Target: $${target.toFixed(2)} | Stop: $${stop.toFixed(
        2
      )}`
    );
  } else {
    // SHORT: SELL to open
    const target = price * (1 - strategy.targetPercent / 100);
    const stop = price * (1 + strategy.stopLossPercent / 100);

    paperSell(symbol, qty, price);

    await Trade.create({
      symbol,
      side: "SELL",
      qty: qty,
      entry_price: price,
      target_price: target,
      stop_loss: stop,
      mode: process.env.TRADING_MODE,
    });

    openTrades[symbol] = true;
    const count = tradeCount[symbol] || 0;
    tradeCount[symbol] = count + 1;
    console.log(
      `🔴 SHORT ${symbol} | Qty: ${qty} @ $${price.toFixed(2)} | Target: $${target.toFixed(2)} | Stop: $${stop.toFixed(
        2
      )}`
    );
  }
}

export function closeTrade(symbol) {
  openTrades[symbol] = false;
}
