export default (sequelize, DataTypes) => {
  return sequelize.define("Trade", {
    symbol: DataTypes.STRING,
    side: DataTypes.STRING,
    qty: DataTypes.FLOAT,
    entry_price: DataTypes.FLOAT,
    exit_price: DataTypes.FLOAT,
    target_price: DataTypes.FLOAT,
    stop_loss: DataTypes.FLOAT,
    status: { type: DataTypes.STRING, defaultValue: "OPEN" },
    pnl: DataTypes.FLOAT,
    mode: DataTypes.STRING
  });
};
