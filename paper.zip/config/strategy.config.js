export default {
  timeframe: "1m",
  targetPercent: 0.4,
  stopLossPercent: 0.25,
  maxTradesPerCoin: 5,
  cooldownAfterLoss: 180,
};
