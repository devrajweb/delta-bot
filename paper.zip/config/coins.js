export default [
  { symbol: "BTCUSD", qty: 0.000116 },
  { symbol: "ETHUSD", qty: 0.01 },
  { symbol: "SOLUSD", qty: 1 },
  { symbol: "DOGEUSD", qty: 200 },
];
