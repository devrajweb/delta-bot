// Migration file template - Copy and modify this for new migrations
module.exports = {
  up: async (queryInterface, Sequelize) => {
    // Add migration code here
  },

  down: async (queryInterface, Sequelize) => {
    // Add rollback code here
  },
};
